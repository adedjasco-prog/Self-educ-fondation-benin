# 🇧🇯 Fondation Bénin

**Plateforme éducative PWA pour le Bénin et l'Afrique francophone**

Du préscolaire (Section des Petits, 2.5 ans) au lycée (Terminale, 18 ans) — avec diagnostic pour adultes et auto-apprentissage.

---

## 🎯 Fonctionnalités

### Pour les enfants (3-5 ans)
- 🎬 Vidéos éducatives gratuites (Khan Academy Kids, comptines locales)
- 🎮 Jeux interactifs pour apprendre en s'amusant
- 🔊 Audio en français et en langues locales (Fon, Yoruba, Dendi)
- 🖐️ Interface tactile adaptée aux petits doigts

### Pour les adultes
- 🧪 **Test de diagnostic** pour trouver votre niveau réel
- 📚 Apprentissage depuis les bases (pas de jugement)
- 🎯 Préparation aux examens: CEP, BEPC, BAC, JAMB
- 🔄 Mode remise à niveau pour combler les lacunes

### Pour tous
- 📱 **PWA installable** (Android, iOS, Desktop)
- 📡 **Mode hors ligne** — téléchargez et apprenez sans Internet
- 💾 **Mode économie de données** — audio uniquement, texte compressé
- 🌍 **Multilingue** — Français, Fon, Yoruba, Dendi, Bariba, Pidgin
- 📝 **Notes personnelles** style Notion pour chaque concept
- 🔗 **Graphe de connaissances** — prérequis et concepts liés
- ⭐ **Plusieurs explications** par concept — trouvez celle qui vous convient

---

## 🏗️ Architecture

```
Next.js 14 (App Router)
├── PWA (Service Worker + Manifest)
├── Tailwind CSS + shadcn/ui
├── Supabase (PostgreSQL + Auth)
├── IndexedDB (Offline Storage)
└── YouTube Embed (Free video content)
```

---

## 🚀 Installation

### 1. Cloner et installer
```bash
git clone <repo-url>
cd fondation-benin
npm install
```

### 2. Configurer Supabase
```bash
# Créer un projet sur https://supabase.com
# Copier les credentials dans .env.local
```

Créer `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 3. Initialiser la base de données
```bash
# Exécuter le fichier SQL dans l'éditeur SQL de Supabase
supabase/schema.sql
```

### 4. Lancer en développement
```bash
npm run dev
```

### 5. Construire pour production
```bash
npm run build
```

---

## 📁 Structure du projet

```
fondation-benin/
├── app/
│   ├── layout.tsx          # Layout racine avec PWA config
│   ├── page.tsx            # Page d'accueil + onboarding
│   ├── globals.css         # Styles Tailwind + custom
│   ├── diagnostic/
│   │   └── page.tsx        # Test de niveau adaptatif
│   ├── curriculum/
│   │   └── page.tsx        # Navigateur de programme
│   └── concept/
│       └── [slug]/
│           └── page.tsx    # Page concept (Notion-style)
├── components/             # Composants réutilisables
├── lib/
│   ├── mockData.ts         # Données de démo (curriculum Bénin)
│   ├── supabase.ts         # Client Supabase
│   └── offlineStorage.ts   # IndexedDB utilities
├── types/
│   └── index.ts            # Types TypeScript
├── supabase/
│   └── schema.sql          # Schéma complet PostgreSQL
├── public/
│   ├── manifest.json       # PWA manifest
│   ├── sw.js               # Service Worker
│   └── offline.html        # Page hors ligne
└── package.json
```

---

## 📚 Curriculum Bénin intégré

Basé sur le **Programme Officiel de l'Éducation Préscolaire au Bénin**:

| Niveau | Âge | Durée | Focus |
|--------|-----|-------|-------|
| **Section des Petits** | 2.5-3.5 ans | 1 an | Éveil et stimulation |
| **Section des Grands** | 3.5-5.5 ans | 2 ans | Apprentissages fondamentaux |
| **CI à CM2** | 5-11 ans | 6 ans | Fondamentaux |
| **6ème à 3ème** | 11-15 ans | 4 ans | Collège |
| **2nde à Tle** | 15-18 ans | 3 ans | Lycée + examens |

---

## 🌍 Sources de contenu gratuit

| Source | Type | Langue | Niveau |
|--------|------|--------|--------|
| Khan Academy Kids | Vidéo/App | FR/EN | Préscolaire |
| African Storybook | Livres | FR/Local | Primaire |
| YouTube Éducation | Vidéos | FR/Fon | Tous |
| PhET Simulations | Interactif | FR | Secondaire |
| WASSCE/NECO archives | Examens | FR | Lycée |
| MIT OpenCourseWare | Cours | EN | Université |

---

## 💰 Coût d'exploitation (MVP)

| Service | Coût mensuel |
|---------|-------------|
| Supabase (Free Tier) | **0 $** |
| Vercel (Free Tier) | **0 $** |
| YouTube (Embed) | **0 $** |
| **Total** | **0 $** |

*Jusqu'à 500MB de base de données et 50K utilisateurs/mois.*

---

## 🤝 Contribuer

1. Fork le projet
2. Créer une branche: `git checkout -b feature/ma-fonctionnalite`
3. Commit: `git commit -m 'Ajout de ma fonctionnalité'`
4. Push: `git push origin feature/ma-fonctionnalite`
5. Ouvrir une Pull Request

---

## 📄 Licence

MIT License — Éducation pour tous.

---

**Fait avec ❤️ pour le Bénin et l'Afrique francophone.**

*"L'éducation est l'arme la plus puissante pour changer le monde." — Nelson Mandela*
