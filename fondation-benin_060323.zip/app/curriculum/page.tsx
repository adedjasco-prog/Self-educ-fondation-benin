'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ChevronRight, Lock, Unlock, Star, BookOpen } from 'lucide-react';
import { educationLevels, subjects, mockConcepts } from '@/lib/mockData';

export default function CurriculumPage() {
  const router = useRouter();
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);

  const filteredConcepts = mockConcepts.filter(c => {
    if (selectedLevel !== null) {
      // In real app, concepts would have level_id
      // For demo, we show all concepts
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-warm-cream">
      <header className="bg-benin-green text-white p-4 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto flex items-center">
          <button onClick={() => router.push('/')} className="mr-4">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="font-bold text-lg">Programme scolaire</h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4">
        {/* Level Selector */}
        <section className="mb-6">
          <h2 className="font-bold text-lg mb-3">Choisir un niveau</h2>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {educationLevels.map((level) => (
              <button
                key={level.id}
                onClick={() => setSelectedLevel(level.id)}
                className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                  selectedLevel === level.id
                    ? 'bg-benin-green text-white'
                    : 'bg-white text-gray-700 border border-gray-200'
                }`}
              >
                {level.name_fr.split(' ')[0]}
              </button>
            ))}
          </div>
        </section>

        {/* Subject Selector */}
        <section className="mb-6">
          <h2 className="font-bold text-lg mb-3">Matière</h2>
          <div className="grid grid-cols-3 gap-3">
            {subjects.map((subject) => (
              <button
                key={subject.id}
                onClick={() => setSelectedSubject(subject.id)}
                className={`p-3 rounded-2xl border-2 text-center transition-all ${
                  selectedSubject === subject.id
                    ? 'border-benin-green bg-green-50'
                    : 'border-gray-200 bg-white'
                }`}
              >
                <span className="text-2xl block mb-1">
                  {subject.icon === 'BookOpen' && '📖'}
                  {subject.icon === 'Calculator' && '🔢'}
                  {subject.icon === 'Globe' && '🌍'}
                  {subject.icon === 'Palette' && '🎨'}
                  {subject.icon === 'Wrench' && '🔧'}
                  {subject.icon === 'Users' && '👥'}
                </span>
                <span className="text-xs font-semibold">{subject.name_fr.split(' ')[0]}</span>
              </button>
            ))}
          </div>
        </section>

        {/* Concepts List */}
        <section>
          <h2 className="font-bold text-lg mb-3">
            Concepts - Section des Petits (Math)
          </h2>
          <div className="space-y-3">
            {filteredConcepts.map((concept, idx) => (
              <div
                key={concept.id}
                onClick={() => router.push(`/concept/${concept.slug}`)}
                className="bg-white rounded-2xl shadow-md p-4 cursor-pointer hover:shadow-lg transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs bg-gray-100 px-2 py-0.5 rounded-full text-gray-600">
                        {concept.concept_code}
                      </span>
                      {idx === 0 && (
                        <span className="text-xs bg-green-100 text-benin-green px-2 py-0.5 rounded-full">
                          Disponible
                        </span>
                      )}
                      {idx > 0 && (
                        <span className="text-xs bg-gray-100 text-gray-400 px-2 py-0.5 rounded-full">
                          <Lock className="inline w-3 h-3 mr-1" />
                          Verrouillé
                        </span>
                      )}
                    </div>
                    <h3 className="font-bold text-gray-800">{concept.title_fr}</h3>
                    <p className="text-sm text-gray-500">{concept.title_en}</p>
                    {concept.title_local && (
                      <p className="text-xs text-benin-green mt-1">{concept.title_local}</p>
                    )}
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                      <span>⏱️ {concept.estimated_minutes} min</span>
                      <span>📚 {concept.competence_fr}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-300" />
                </div>

                {/* Progress bar for first concept */}
                {idx === 0 && (
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                      <span>Progression</span>
                      <span>0%</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div className="bg-benin-green h-2 rounded-full" style={{ width: '0%' }} />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Legend */}
        <div className="mt-6 bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="font-bold text-sm mb-2">Légende</h3>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-green-100 rounded-full" />
              <span>Disponible</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-gray-100 rounded-full" />
              <span>Verrouillé (prérequis manquants)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-benin-green rounded-full" />
              <span>Maîtrisé</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-benin-yellow rounded-full" />
              <span>En cours</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
