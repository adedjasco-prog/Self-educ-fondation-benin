'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ArrowRight, Check, X, Star, Trophy } from 'lucide-react';
import { diagnosticQuestions, educationLevels } from '@/lib/mockData';

export default function DiagnosticPage() {
  const router = useRouter();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  const question = diagnosticQuestions[currentQuestion];
  const totalQuestions = diagnosticQuestions.length;
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  const handleAnswer = (answer: string) => {
    setAnswers({ ...answers, [currentQuestion]: answer });
  };

  const handleNext = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResults();
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const calculateResults = () => {
    let correct = 0;
    Object.entries(answers).forEach(([idx, answer]) => {
      if (answer === diagnosticQuestions[parseInt(idx)].correct) {
        correct++;
      }
    });
    setScore(correct);
    setShowResults(true);
  };

  const getRecommendedLevel = () => {
    // Find the highest level where they got the question right
    let highestCorrectLevel = -1;
    Object.entries(answers).forEach(([idx, answer]) => {
      const qIdx = parseInt(idx);
      if (answer === diagnosticQuestions[qIdx].correct) {
        const levelIdx = educationLevels.findIndex(l => l.code === diagnosticQuestions[qIdx].level);
        if (levelIdx > highestCorrectLevel) {
          highestCorrectLevel = levelIdx;
        }
      }
    });

    if (highestCorrectLevel === -1) return educationLevels[0];
    if (highestCorrectLevel >= educationLevels.length - 1) return educationLevels[educationLevels.length - 1];
    return educationLevels[highestCorrectLevel + 1];
  };

  const getGapLevels = () => {
    const gaps: string[] = [];
    Object.entries(answers).forEach(([idx, answer]) => {
      if (answer !== diagnosticQuestions[parseInt(idx)].correct) {
        gaps.push(diagnosticQuestions[parseInt(idx)].level);
      }
    });
    return [...new Set(gaps)];
  };

  if (showResults) {
    const recommendedLevel = getRecommendedLevel();
    const gapLevels = getGapLevels();
    const percentage = Math.round((score / totalQuestions) * 100);

    return (
      <div className="min-h-screen bg-warm-cream">
        <header className="bg-benin-green text-white p-4">
          <div className="max-w-4xl mx-auto flex items-center">
            <button onClick={() => router.push('/')} className="mr-4">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="font-bold text-lg">Résultats du test</h1>
          </div>
        </header>

        <main className="max-w-4xl mx-auto p-4">
          <div className="bg-white rounded-3xl shadow-lg p-6 text-center">
            <div className="w-24 h-24 bg-benin-yellow rounded-full mx-auto mb-4 flex items-center justify-center">
              <Trophy className="w-12 h-12 text-benin-green" />
            </div>

            <h2 className="text-2xl font-bold mb-2">Test terminé!</h2>
            <p className="text-gray-600 mb-4">
              Vous avez répondu correctement à {score} questions sur {totalQuestions}
            </p>

            <div className="w-full bg-gray-200 rounded-full h-4 mb-6">
              <div 
                className="bg-benin-green h-4 rounded-full transition-all duration-1000"
                style={{ width: `${percentage}%` }}
              />
            </div>

            <div className="bg-green-50 rounded-2xl p-4 mb-4">
              <h3 className="font-bold text-benin-green mb-2">
                🎯 Niveau recommandé
              </h3>
              <p className="text-lg font-semibold">{recommendedLevel.name_fr}</p>
              <p className="text-sm text-gray-600">{recommendedLevel.age_range}</p>
            </div>

            {gapLevels.length > 0 && (
              <div className="bg-orange-50 rounded-2xl p-4 mb-4">
                <h3 className="font-bold text-orange-600 mb-2">
                  ⚠️ Lacunes identifiées
                </h3>
                <p className="text-sm text-gray-600">
                  Nous avons détecté des difficultés aux niveaux: {gapLevels.map(l => 
                    educationLevels.find(el => el.code === l)?.name_fr
                  ).join(', ')}
                </p>
              </div>
            )}

            <div className="flex gap-3 mt-6">
              <button 
                onClick={() => router.push(`/concept/${recommendedLevel.code}`)}
                className="btn-primary flex-1"
              >
                🚀 Commencer ici
              </button>
              <button 
                onClick={() => router.push('/curriculum')}
                className="btn-secondary flex-1"
              >
                📖 Voir tout le programme
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-warm-cream">
      <header className="bg-benin-green text-white p-4 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <button onClick={() => router.push('/')}>
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="font-bold">Test de niveau</h1>
          <span className="text-sm">{currentQuestion + 1}/{totalQuestions}</span>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4">
        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>Progression</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-benin-green h-3 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="bg-white rounded-3xl shadow-lg p-6">
          <div className="mb-2">
            <span className="text-xs bg-gray-100 px-2 py-1 rounded-full text-gray-600">
              {educationLevels.find(l => l.code === question.level)?.name_fr}
            </span>
          </div>

          <h2 className="text-xl font-bold mb-6">{question.question_fr}</h2>

          {question.question_en && (
            <p className="text-sm text-gray-500 mb-4">{question.question_en}</p>
          )}

          {/* Options */}
          <div className="grid grid-cols-2 gap-3">
            {question.options.map((option, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswer(option)}
                className={`p-4 rounded-2xl border-2 text-lg font-semibold transition-all ${
                  answers[currentQuestion] === option
                    ? 'border-benin-green bg-green-50 text-benin-green'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                {option}
              </button>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex justify-between mt-6">
            <button
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
              className={`flex items-center gap-2 px-4 py-2 rounded-full ${
                currentQuestion === 0 
                  ? 'text-gray-300' 
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <ArrowLeft className="w-5 h-5" />
              Précédent
            </button>

            <button
              onClick={handleNext}
              disabled={!answers[currentQuestion]}
              className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold ${
                answers[currentQuestion]
                  ? 'bg-benin-green text-white'
                  : 'bg-gray-200 text-gray-400'
              }`}
            >
              {currentQuestion === totalQuestions - 1 ? 'Terminer' : 'Suivant'}
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tips */}
        <div className="mt-4 bg-blue-50 rounded-2xl p-4">
          <p className="text-sm text-blue-700">
            💡 <strong>Conseil:</strong> Ce test s'adapte à votre niveau. Ne vous inquiétez pas si vous ne connaissez pas toutes les réponses - cela nous aide à trouver par où commencer!
          </p>
        </div>
      </main>
    </div>
  );
}
