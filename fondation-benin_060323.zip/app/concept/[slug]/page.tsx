'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { 
  ArrowLeft, Play, BookOpen, Headphones, Gamepad2, FileText, 
  Star, Download, Check, X, ChevronRight, Lightbulb, 
  Volume2, Pause, RotateCcw, Trophy, Clock, Users
} from 'lucide-react';
import { mockConcepts, mockContentSources, mockExercises } from '@/lib/mockData';

export default function ConceptPage({ params }: { params: { slug: string } }) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<'explanations' | 'exercises' | 'notes'>('explanations');
  const [selectedSource, setSelectedSource] = useState<string | null>(null);
  const [currentExercise, setCurrentExercise] = useState(0);
  const [exerciseAnswer, setExerciseAnswer] = useState<string | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [hintLevel, setHintLevel] = useState(0);
  const [exerciseCompleted, setExerciseCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [noteContent, setNoteContent] = useState('');

  // Find concept by slug
  const concept = mockConcepts.find(c => c.slug === params.slug) || mockConcepts[0];
  const contentSources = mockContentSources[concept.id] || [];
  const exercises = mockExercises[concept.id] || [];
  const currentEx = exercises[currentExercise];

  const handleExerciseSubmit = () => {
    if (!currentEx || !exerciseAnswer) return;
    const isCorrect = exerciseAnswer === currentEx.correct_answer;
    if (isCorrect) setScore(score + currentEx.points);
    setExerciseCompleted(true);
  };

  const handleNextExercise = () => {
    if (currentExercise < exercises.length - 1) {
      setCurrentExercise(currentExercise + 1);
      setExerciseAnswer(null);
      setExerciseCompleted(false);
      setShowHint(false);
      setHintLevel(0);
    }
  };

  const handleShowHint = () => {
    if (currentEx && currentEx.hints && hintLevel < currentEx.hints.length) {
      setShowHint(true);
      setHintLevel(hintLevel + 1);
    }
  };

  const getSourceIcon = (type: string) => {
    switch (type) {
      case 'video': return <Play className="w-5 h-5" />;
      case 'audio': return <Headphones className="w-5 h-5" />;
      case 'interactive': return <Gamepad2 className="w-5 h-5" />;
      case 'text': return <FileText className="w-5 h-5" />;
      default: return <BookOpen className="w-5 h-5" />;
    }
  };

  const getSourceColor = (type: string) => {
    switch (type) {
      case 'video': return 'bg-red-50 text-red-600 border-red-200';
      case 'audio': return 'bg-blue-50 text-blue-600 border-blue-200';
      case 'interactive': return 'bg-purple-50 text-purple-600 border-purple-200';
      case 'text': return 'bg-green-50 text-green-600 border-green-200';
      default: return 'bg-gray-50 text-gray-600 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-warm-cream">
      {/* Header */}
      <header className="bg-benin-green text-white p-4 sticky top-0 z-40 shadow-lg">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <button onClick={() => router.push('/curriculum')} className="flex items-center gap-2">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="text-center flex-1 mx-4">
            <h1 className="font-bold text-sm truncate">{concept.title_fr}</h1>
            <p className="text-xs text-green-200">{concept.concept_code}</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs bg-green-700 px-2 py-1 rounded-full">
              ⭐ {score}
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4">
        {/* Concept Header Card */}
        <div className="bg-white rounded-3xl shadow-lg p-6 mb-4">
          <div className="flex items-start justify-between mb-4">
            <div>
              <span className="text-xs bg-benin-yellow text-gray-800 px-2 py-1 rounded-full font-semibold">
                {concept.niveau_maitrise}
              </span>
              <h2 className="text-2xl font-bold mt-2 text-gray-800">{concept.title_fr}</h2>
              <p className="text-gray-500">{concept.title_en}</p>
              {concept.title_local && (
                <p className="text-sm text-benin-green font-semibold mt-1">{concept.title_local}</p>
              )}
            </div>
            <div className="text-right">
              <div className="w-12 h-12 bg-benin-green rounded-2xl flex items-center justify-center">
                <span className="text-2xl">🔢</span>
              </div>
            </div>
          </div>

          {/* Learning Objective */}
          <div className="bg-green-50 rounded-2xl p-4 mb-4">
            <div className="flex items-start gap-2">
              <Lightbulb className="w-5 h-5 text-benin-green flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-benin-green text-sm">Objectif d'apprentissage</p>
                <p className="text-gray-700 text-sm mt-1">{concept.learning_objective_fr}</p>
                <p className="text-gray-500 text-xs mt-1">{concept.learning_objective_en}</p>
              </div>
            </div>
          </div>

          {/* Meta Info */}
          <div className="flex flex-wrap gap-3 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {concept.estimated_minutes} min
            </span>
            <span className="flex items-center gap-1">
              <BookOpen className="w-4 h-4" />
              {concept.competence_fr}
            </span>
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              {contentSources.length} sources
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-2xl shadow-md p-1 mb-4 flex">
          <button
            onClick={() => setActiveTab('explanations')}
            className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'explanations'
                ? 'bg-benin-green text-white'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            📚 Explications ({contentSources.length})
          </button>
          <button
            onClick={() => setActiveTab('exercises')}
            className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'exercises'
                ? 'bg-benin-green text-white'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            ✏️ Exercices ({exercises.length})
          </button>
          <button
            onClick={() => setActiveTab('notes')}
            className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'notes'
                ? 'bg-benin-green text-white'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            📝 Mes notes
          </button>
        </div>

        {/* Explanations Tab */}
        {activeTab === 'explanations' && (
          <div className="space-y-3">
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <h3 className="font-bold text-gray-700 mb-3">
                Choisissez votre style d'apprentissage
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                Chaque concept est expliqué de plusieurs façons. Trouvez celle qui vous convient le mieux!
              </p>
            </div>

            {contentSources.map((source) => (
              <div
                key={source.id}
                className={`bg-white rounded-2xl shadow-md overflow-hidden transition-all ${
                  selectedSource === source.id ? 'ring-2 ring-benin-green' : ''
                }`}
              >
                {/* Source Header */}
                <div
                  onClick={() => setSelectedSource(selectedSource === source.id ? null : source.id)}
                  className="p-4 cursor-pointer"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${getSourceColor(source.source_type)}`}>
                        {getSourceIcon(source.source_type)}
                      </div>
                      <div>
                        <h4 className="font-bold text-sm">{source.title_fr}</h4>
                        <p className="text-xs text-gray-500">{source.title_en}</p>
                        <div className="flex items-center gap-2 mt-1 text-xs text-gray-400">
                          <span className="flex items-center gap-1">
                            <Star className="w-3 h-3 text-yellow-400" />
                            {source.rating_average}
                          </span>
                          <span>({source.rating_count} avis)</span>
                          <span>•</span>
                          <span>{source.explanation_style}</span>
                          {source.duration_seconds && (
                            <>
                              <span>•</span>
                              <span>{Math.round(source.duration_seconds / 60)} min</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      {source.offline_available && (
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Download className="w-3 h-3" />
                          Offline
                        </span>
                      )}
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
                        {source.language}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Expanded Content */}
                {selectedSource === source.id && (
                  <div className="border-t border-gray-100 p-4">
                    {source.source_type === 'video' && (
                      <div className="aspect-video bg-gray-900 rounded-xl overflow-hidden mb-3">
                        <iframe
                          src={source.source_url}
                          title={source.title_fr}
                          className="w-full h-full"
                          allowFullScreen
                        />
                      </div>
                    )}

                    {source.source_type === 'audio' && (
                      <div className="bg-blue-50 rounded-xl p-4 mb-3">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => setIsPlaying(!isPlaying)}
                            className="w-12 h-12 bg-benin-green rounded-full flex items-center justify-center text-white"
                          >
                            {isPlaying ? <Pause className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                          </button>
                          <div className="flex-1">
                            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div className="h-full bg-benin-green rounded-full" style={{ width: '30%' }} />
                            </div>
                            <div className="flex justify-between text-xs text-gray-500 mt-1">
                              <span>0:27</span>
                              <span>{Math.round((source.duration_seconds || 0) / 60)}:00</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {source.source_type === 'interactive' && (
                      <div className="bg-purple-50 rounded-xl p-6 text-center mb-3">
                        <Gamepad2 className="w-12 h-12 text-purple-600 mx-auto mb-2" />
                        <p className="font-bold text-purple-800">Jeu interactif</p>
                        <p className="text-sm text-purple-600 mb-3">{source.description_fr}</p>
                        <button className="bg-purple-600 text-white px-6 py-2 rounded-full font-semibold">
                          🎮 Jouer maintenant
                        </button>
                      </div>
                    )}

                    <div className="flex gap-2">
                      <button className="flex-1 bg-benin-green text-white py-2 rounded-xl text-sm font-semibold flex items-center justify-center gap-2">
                        <Check className="w-4 h-4" />
                        J'ai compris
                      </button>
                      {source.offline_available && (
                        <button className="px-4 py-2 bg-gray-100 rounded-xl text-sm flex items-center gap-1">
                          <Download className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}

            {/* Add Source CTA */}
            <div className="bg-white rounded-2xl p-4 shadow-sm border-2 border-dashed border-gray-300 text-center">
              <p className="text-sm text-gray-500 mb-2">
                Vous connaissez une meilleure explication?
              </p>
              <button className="text-benin-green font-semibold text-sm">
                + Proposer une source
              </button>
            </div>
          </div>
        )}

        {/* Exercises Tab */}
        {activeTab === 'exercises' && (
          <div className="space-y-3">
            {exercises.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center shadow-md">
                <Trophy className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                <p className="text-gray-500">Pas encore d'exercices pour ce concept</p>
              </div>
            ) : (
              <>
                {/* Exercise Progress */}
                <div className="bg-white rounded-2xl p-4 shadow-sm">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Exercice {currentExercise + 1} sur {exercises.length}</span>
                    <span>Score: {score} pts</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-benin-green h-2 rounded-full transition-all"
                      style={{ width: `${((currentExercise + 1) / exercises.length) * 100}%` }}
                    />
                  </div>
                </div>

                {currentEx && (
                  <div className="bg-white rounded-2xl shadow-lg p-6">
                    {/* Exercise Header */}
                    <div className="flex items-center justify-between mb-4">
                      <span className={`text-xs px-3 py-1 rounded-full font-semibold ${
                        currentEx.difficulty === 'débutant' ? 'bg-green-100 text-green-700' :
                        currentEx.difficulty === 'intermédiaire' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {currentEx.difficulty === 'débutant' ? '🟢' : 
                         currentEx.difficulty === 'intermédiaire' ? '🟡' : '🔴'} {currentEx.difficulty}
                      </span>
                      {currentEx.time_limit_seconds && (
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {currentEx.time_limit_seconds}s
                        </span>
                      )}
                    </div>

                    <h3 className="font-bold text-lg mb-2">{currentEx.title_fr}</h3>
                    <p className="text-sm text-gray-600 mb-4">{currentEx.instructions_fr}</p>

                    {/* Question */}
                    <div className="bg-gray-50 rounded-xl p-4 mb-4">
                      <p className="font-semibold text-gray-800">{currentEx.question_text_fr}</p>
                      <p className="text-sm text-gray-500 mt-1">{currentEx.question_text_en}</p>
                    </div>

                    {/* Options */}
                    {!exerciseCompleted ? (
                      <div className="grid grid-cols-1 gap-3 mb-4">
                        {currentEx.options?.map((option: any) => (
                          <button
                            key={option.id}
                            onClick={() => setExerciseAnswer(option.id)}
                            className={`p-4 rounded-xl border-2 text-left transition-all ${
                              exerciseAnswer === option.id
                                ? 'border-benin-green bg-green-50'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
                                exerciseAnswer === option.id
                                  ? 'border-benin-green bg-benin-green text-white'
                                  : 'border-gray-300'
                              }`}>
                                {option.id.toUpperCase()}
                              </div>
                              <span className="font-semibold">{option.label}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className={`rounded-xl p-4 mb-4 ${
                        exerciseAnswer === currentEx.correct_answer
                          ? 'bg-green-50 border-2 border-green-200'
                          : 'bg-red-50 border-2 border-red-200'
                      }`}>
                        <div className="flex items-center gap-2 mb-2">
                          {exerciseAnswer === currentEx.correct_answer ? (
                            <>
                              <Check className="w-6 h-6 text-green-600" />
                              <span className="font-bold text-green-700">Correct! +{currentEx.points} points</span>
                            </>
                          ) : (
                            <>
                              <X className="w-6 h-6 text-red-600" />
                              <span className="font-bold text-red-700">Incorrect</span>
                            </>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">
                          La bonne réponse était: <strong>{
                            currentEx.options?.find((o: any) => o.id === currentEx.correct_answer)?.label
                          }</strong>
                        </p>
                      </div>
                    )}

                    {/* Hints */}
                    {showHint && currentEx.hints && currentEx.hints[hintLevel - 1] && (
                      <div className="bg-yellow-50 rounded-xl p-4 mb-4 border-2 border-yellow-200">
                        <div className="flex items-start gap-2">
                          <Lightbulb className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="font-semibold text-yellow-800 text-sm">Indice {hintLevel}</p>
                            <p className="text-sm text-yellow-700">
                              {currentEx.hints[hintLevel - 1].texte_fr}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex gap-3">
                      {!exerciseCompleted ? (
                        <>
                          <button
                            onClick={handleShowHint}
                            disabled={!currentEx.hints || hintLevel >= (currentEx.hints?.length || 0)}
                            className="px-4 py-3 bg-yellow-100 text-yellow-700 rounded-xl text-sm font-semibold disabled:opacity-50"
                          >
                            💡 Indice
                          </button>
                          <button
                            onClick={handleExerciseSubmit}
                            disabled={!exerciseAnswer}
                            className="flex-1 bg-benin-green text-white py-3 rounded-xl font-semibold disabled:opacity-50"
                          >
                            Vérifier ma réponse
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={() => {
                              setExerciseAnswer(null);
                              setExerciseCompleted(false);
                              setShowHint(false);
                              setHintLevel(0);
                            }}
                            className="px-4 py-3 bg-gray-100 text-gray-700 rounded-xl text-sm font-semibold flex items-center gap-2"
                          >
                            <RotateCcw className="w-4 h-4" />
                            Réessayer
                          </button>
                          {currentExercise < exercises.length - 1 ? (
                            <button
                              onClick={handleNextExercise}
                              className="flex-1 bg-benin-green text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2"
                            >
                              Exercice suivant
                              <ChevronRight className="w-5 h-5" />
                            </button>
                          ) : (
                            <button
                              onClick={() => router.push('/curriculum')}
                              className="flex-1 bg-benin-yellow text-gray-800 py-3 rounded-xl font-semibold"
                            >
                              🎉 Terminé! Retour au programme
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Notes Tab */}
        {activeTab === 'notes' && (
          <div className="space-y-3">
            <div className="bg-white rounded-2xl shadow-md p-4">
              <h3 className="font-bold text-gray-700 mb-2">📝 Mes notes sur ce concept</h3>
              <p className="text-sm text-gray-500 mb-3">
                Prenez des notes, dessinez, ou enregistrez vos propres explications.
              </p>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="Écrivez vos notes ici... (supporte le markdown)"
                className="w-full h-40 p-4 border-2 border-gray-200 rounded-xl resize-none focus:border-benin-green focus:outline-none text-sm"
              />
              <div className="flex gap-2 mt-3">
                <button className="px-3 py-2 bg-gray-100 rounded-lg text-sm flex items-center gap-1">
                  📷 Photo
                </button>
                <button className="px-3 py-2 bg-gray-100 rounded-lg text-sm flex items-center gap-1">
                  🎤 Audio
                </button>
                <button className="px-3 py-2 bg-gray-100 rounded-lg text-sm flex items-center gap-1">
                  ✏️ Dessin
                </button>
                <button className="flex-1 bg-benin-green text-white py-2 rounded-lg text-sm font-semibold">
                  💾 Sauvegarder
                </button>
              </div>
            </div>

            {/* Sample Note */}
            <div className="bg-white rounded-2xl shadow-md p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-400">Aujourd'hui, 14:30</span>
                <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Privé</span>
              </div>
              <p className="text-sm text-gray-700">
                J'ai expliqué à mon petit frère que compter, c'est comme compter les mangues au marché de Dantokpa. 
                1 mangue, 2 mangues, 3 mangues...
              </p>
            </div>
          </div>
        )}

        {/* Related Concepts */}
        <div className="mt-6 bg-white rounded-2xl shadow-md p-4">
          <h3 className="font-bold text-gray-700 mb-3">🔗 Concepts liés</h3>
          <div className="space-y-2">
            {concept.prerequisite_concepts && concept.prerequisite_concepts.length > 0 && (
              <div>
                <p className="text-xs text-gray-500 mb-1">Prérequis (à connaître avant)</p>
                {concept.prerequisite_concepts.map((prereqId) => {
                  const prereq = mockConcepts.find(c => c.id === prereqId);
                  return prereq ? (
                    <button
                      key={prereqId}
                      onClick={() => router.push(`/concept/${prereq.slug}`)}
                      className="w-full text-left p-3 bg-gray-50 rounded-xl text-sm hover:bg-gray-100 transition-all"
                    >
                      ← {prereq.title_fr}
                    </button>
                  ) : null;
                })}
              </div>
            )}

            {concept.leads_to_concepts && concept.leads_to_concepts.length > 0 && (
              <div>
                <p className="text-xs text-gray-500 mb-1">Ensuite (à apprendre après)</p>
                {concept.leads_to_concepts.map((nextId) => {
                  const next = mockConcepts.find(c => c.id === nextId);
                  return next ? (
                    <button
                      key={nextId}
                      onClick={() => router.push(`/concept/${next.slug}`)}
                      className="w-full text-left p-3 bg-green-50 rounded-xl text-sm hover:bg-green-100 transition-all text-benin-green"
                    >
                      {next.title_fr} →
                    </button>
                  ) : null;
                })}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
