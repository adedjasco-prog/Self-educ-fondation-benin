'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { BookOpen, Calculator, Globe, Palette, Wrench, Users, Play, Star, Download, Wifi, WifiOff } from 'lucide-react';
import { educationLevels, subjects } from '@/lib/mockData';

export default function Home() {
  const router = useRouter();
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [userType, setUserType] = useState<'enfant' | 'parent' | 'adulte' | null>(null);
  const [goal, setGoal] = useState<string>('');

  const handleStart = () => {
    setShowOnboarding(true);
  };

  const handleDiagnostic = () => {
    router.push('/diagnostic');
  };

  const handleBrowse = () => {
    router.push('/curriculum');
  };

  return (
    <div className="min-h-screen bg-warm-cream">
      {/* Header */}
      <header className="bg-benin-green text-white p-4 sticky top-0 z-40 shadow-lg">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-benin-yellow rounded-full flex items-center justify-center">
              <span className="text-benin-green font-bold text-xl">FB</span>
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">Fondation Bénin</h1>
              <p className="text-xs text-green-100">Éducation pour tous</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs bg-green-700 px-2 py-1 rounded-full">🇧🇯 Bénin</span>
            <span className="text-xs bg-green-700 px-2 py-1 rounded-full">Français</span>
          </div>
        </div>
      </header>

      {!showOnboarding ? (
        /* Landing Page */
        <main className="max-w-4xl mx-auto p-4">
          {/* Hero */}
          <section className="text-center py-8">
            <div className="w-24 h-24 bg-benin-yellow rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
              <span className="text-4xl">📚</span>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">
              Apprenez à votre rythme
            </h2>
            <p className="text-gray-600 mb-6 max-w-md mx-auto">
              Du préscolaire au lycée, du Bénin à toute l'Afrique francophone. 
              Des milliers de leçons gratuites, expliquées de plusieurs façons.
            </p>
            <button onClick={handleStart} className="btn-primary text-xl px-8 py-4">
              <Play className="inline w-5 h-5 mr-2" />
              Commencer à apprendre
            </button>
          </section>

          {/* Features */}
          <section className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-white rounded-2xl p-4 shadow-md">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-2">
                <Play className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-bold text-sm">Vidéos gratuites</h3>
              <p className="text-xs text-gray-500">Khan Academy, YouTube, enseignants locaux</p>
            </div>
            <div className="bg-white rounded-2xl p-4 shadow-md">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-2">
                <Download className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-bold text-sm">Hors ligne</h3>
              <p className="text-xs text-gray-500">Téléchargez et apprenez sans Internet</p>
            </div>
            <div className="bg-white rounded-2xl p-4 shadow-md">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-2">
                <Star className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-bold text-sm">Plusieurs explications</h3>
              <p className="text-xs text-gray-500">Trouvez celle qui vous convient</p>
            </div>
            <div className="bg-white rounded-2xl p-4 shadow-md">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-2">
                <WifiOff className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="font-bold text-sm">Mode économie</h3>
              <p className="text-xs text-gray-500">Audio uniquement, peu de données</p>
            </div>
          </section>

          {/* Subjects Preview */}
          <section className="mb-8">
            <h3 className="font-bold text-lg mb-3">Matières disponibles</h3>
            <div className="grid grid-cols-3 gap-3">
              {subjects.map((subject) => (
                <div key={subject.id} className="bg-white rounded-xl p-3 shadow-sm text-center">
                  <div 
                    className="w-10 h-10 rounded-lg mx-auto mb-1 flex items-center justify-center"
                    style={{ backgroundColor: subject.color + '20' }}
                  >
                    <span className="text-lg">
                      {subject.icon === 'BookOpen' && '📖'}
                      {subject.icon === 'Calculator' && '🔢'}
                      {subject.icon === 'Globe' && '🌍'}
                      {subject.icon === 'Palette' && '🎨'}
                      {subject.icon === 'Wrench' && '🔧'}
                      {subject.icon === 'Users' && '👥'}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-gray-700">{subject.name_fr}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Levels Preview */}
          <section className="mb-8">
            <h3 className="font-bold text-lg mb-3">Niveaux</h3>
            <div className="bg-white rounded-2xl shadow-md overflow-hidden">
              {educationLevels.slice(0, 6).map((level, idx) => (
                <div 
                  key={level.id} 
                  className={`p-3 flex items-center justify-between ${idx !== 5 ? 'border-b border-gray-100' : ''}`}
                >
                  <div>
                    <p className="font-semibold text-sm">{level.name_fr}</p>
                    <p className="text-xs text-gray-500">{level.age_range}</p>
                  </div>
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                    {level.order_index === 0 ? 'Début' : '...'}
                  </span>
                </div>
              ))}
              <div className="p-3 text-center text-sm text-benin-green font-semibold">
                + 9 autres niveaux jusqu'à la Terminale
              </div>
            </div>
          </section>

          {/* CTA */}
          <section className="text-center py-4">
            <button onClick={handleStart} className="btn-primary text-lg px-6 py-3 mb-3 w-full">
              🚀 Commencer maintenant
            </button>
            <p className="text-xs text-gray-500">
              100% gratuit • Fonctionne hors ligne • Pour tous les âges
            </p>
          </section>
        </main>
      ) : (
        /* Onboarding Flow */
        <main className="max-w-4xl mx-auto p-4">
          <div className="bg-white rounded-3xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-center mb-6">
              {userType === null ? 'Qui êtes-vous?' : 
               goal === '' ? 'Quel est votre objectif?' : 
               'Parfait! Commençons'}
            </h2>

            {userType === null && (
              <div className="grid grid-cols-1 gap-3">
                <button 
                  onClick={() => setUserType('enfant')}
                  className="p-4 rounded-2xl border-2 border-gray-200 hover:border-benin-green hover:bg-green-50 transition-all text-left"
                >
                  <span className="text-2xl mr-3">👶</span>
                  <span className="font-bold">Je suis un enfant</span>
                  <p className="text-sm text-gray-500 ml-10">3-11 ans, j'apprends avec mes parents</p>
                </button>
                <button 
                  onClick={() => setUserType('parent')}
                  className="p-4 rounded-2xl border-2 border-gray-200 hover:border-benin-green hover:bg-green-50 transition-all text-left"
                >
                  <span className="text-2xl mr-3">👨‍👩‍👧</span>
                  <span className="font-bold">Je suis un parent</span>
                  <p className="text-sm text-gray-500 ml-10">J'aide mon enfant à apprendre</p>
                </button>
                <button 
                  onClick={() => setUserType('adulte')}
                  className="p-4 rounded-2xl border-2 border-gray-200 hover:border-benin-green hover:bg-green-50 transition-all text-left"
                >
                  <span className="text-2xl mr-3">🎓</span>
                  <span className="font-bold">Je suis un adulte</span>
                  <p className="text-sm text-gray-500 ml-10">J'apprends pour moi ou pour un examen</p>
                </button>
              </div>
            )}

            {userType !== null && goal === '' && (
              <div className="grid grid-cols-1 gap-3">
                <button 
                  onClick={() => setGoal('apprendre')}
                  className="p-4 rounded-2xl border-2 border-gray-200 hover:border-benin-green hover:bg-green-50 transition-all text-left"
                >
                  <span className="text-2xl mr-3">📚</span>
                  <span className="font-bold">Apprendre du début</span>
                  <p className="text-sm text-gray-500 ml-10">Commencer par les bases et progresser</p>
                </button>
                <button 
                  onClick={() => setGoal('examen')}
                  className="p-4 rounded-2xl border-2 border-gray-200 hover:border-benin-green hover:bg-green-50 transition-all text-left"
                >
                  <span className="text-2xl mr-3">📝</span>
                  <span className="font-bold">Préparer un examen</span>
                  <p className="text-sm text-gray-500 ml-10">CEP, BEPC, BAC, ou autre</p>
                </button>
                <button 
                  onClick={() => setGoal('remise_niveau')}
                  className="p-4 rounded-2xl border-2 border-gray-200 hover:border-benin-green hover:bg-green-50 transition-all text-left"
                >
                  <span className="text-2xl mr-3">🔄</span>
                  <span className="font-bold">Me remettre à niveau</span>
                  <p className="text-sm text-gray-500 ml-10">Combler mes lacunes</p>
                </button>
              </div>
            )}

            {userType !== null && goal !== '' && (
              <div className="text-center">
                <div className="w-20 h-20 bg-benin-green rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-3xl">🎯</span>
                </div>
                <p className="text-gray-600 mb-6">
                  {goal === 'apprendre' ? 'Nous allons vous guider pas à pas depuis le début.' :
                   goal === 'examen' ? 'Faisons un test rapide pour trouver votre niveau.' :
                   'Faisons un diagnostic pour identifier vos lacunes.'}
                </p>
                <div className="flex gap-3">
                  <button onClick={handleDiagnostic} className="btn-primary flex-1">
                    🧪 Test de niveau (5 min)
                  </button>
                  <button onClick={handleBrowse} className="btn-secondary flex-1">
                    📖 Explorer le programme
                  </button>
                </div>
              </div>
            )}
          </div>
        </main>
      )}

      {/* Footer */}
      <footer className="bg-gray-800 text-white p-4 mt-8">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-sm mb-2">Fondation Bénin - Éducation pour tous</p>
          <p className="text-xs text-gray-400">
            Basé sur le programme officiel du Bénin • Contenu gratuit • Open source
          </p>
        </div>
      </footer>
    </div>
  );
}
