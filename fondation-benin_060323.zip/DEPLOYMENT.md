# 🚀 Guide de Déploiement - Fondation Bénin

## Étape 1: Prérequis

- Node.js 18+ installé
- Compte GitHub
- Compte Vercel (gratuit)
- Compte Supabase (gratuit)

---

## Étape 2: Configurer Supabase

### 2.1 Créer un projet
1. Allez sur https://supabase.com
2. Cliquez "New Project"
3. Nommez-le: `fondation-benin`
4. Choisissez la région la plus proche (Frankfurt pour l'Afrique de l'Ouest)
5. Attendez la création (~2 minutes)

### 2.2 Récupérer les credentials
1. Allez dans **Project Settings > API**
2. Copiez:
   - `URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### 2.3 Initialiser la base de données
1. Allez dans **SQL Editor**
2. Créez une "New query"
3. Copiez-collez tout le contenu de `supabase/schema.sql`
4. Cliquez **Run**

### 2.4 Activer l'authentification par téléphone (optionnel)
1. Allez dans **Authentication > Providers**
2. Activez **Phone**
3. Configurez Twilio ou utilisez le provider de test

---

## Étape 3: Déployer sur Vercel

### 3.1 Connecter le repo
1. Allez sur https://vercel.com
2. Cliquez "Add New Project"
3. Importez depuis GitHub
4. Sélectionnez votre repo `fondation-benin`

### 3.2 Configurer les variables d'environnement
Dans les settings du projet Vercel, ajoutez:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 3.3 Déployer
1. Cliquez **Deploy**
2. Attendez la construction (~2-3 minutes)
3. Votre app est en ligne! 🎉

---

## Étape 4: Configurer le domaine personnalisé (optionnel)

1. Dans Vercel, allez dans **Settings > Domains**
2. Ajoutez votre domaine: `fondationbenin.com`
3. Suivez les instructions DNS

---

## Étape 5: Tester le PWA

### Sur Android:
1. Ouvrez l'URL dans Chrome
2. Vous verrez une popup "Ajouter à l'écran d'accueil"
3. Acceptez — l'app s'installe comme une app native

### Sur iOS:
1. Ouvrez l'URL dans Safari
2. Cliquez le bouton "Partager" (carré avec flèche)
3. Sélectionnez "Sur l'écran d'accueil"

### Sur Desktop (Chrome/Edge):
1. Ouvrez l'URL
2. Cliquez l'icône d'installation dans la barre d'adresse
3. L'app s'ouvre dans une fenêtre sans navigateur

---

## Étape 6: Vérifier le mode hors ligne

1. Ouvrez l'app installée
2. Naviguez dans quelques concepts
3. Activez le mode avion sur votre téléphone
4. Revenez à l'app — elle fonctionne toujours!

---

## 🔄 Mises à jour futures

### Ajouter du contenu
1. Connectez-vous à Supabase
2. Allez dans **Table Editor**
3. Ajoutez des concepts, sources de contenu, et exercices

### Ajouter des vidéos locales
1. Uploadez vos vidéos sur YouTube (non listé)
2. Copiez l'URL d'intégration
3. Ajoutez-la comme `source_url` dans la table `content_sources`

### Personnaliser le curriculum
1. Modifiez les données dans `lib/mockData.ts`
2. Ou directement dans Supabase
3. Redéployez si vous modifiez le code

---

## 📊 Monitoring

### Vercel Analytics
- Allez dans **Analytics** sur votre dashboard Vercel
- Voir les visites, les performances, les erreurs

### Supabase Analytics
- Allez dans **Reports** sur Supabase
- Voir l'utilisation de la base de données, les utilisateurs actifs

---

## 🆘 Dépannage

### Problème: L'app ne s'installe pas
- Vérifiez que `manifest.json` est accessible à la racine
- Vérifiez que le service worker est enregistré
- Assurez-vous d'utiliser HTTPS

### Problème: Le mode hors ligne ne fonctionne pas
- Vérifiez que le service worker est correctement enregistré
- Vérifiez la console pour les erreurs
- Assurez-vous que les assets sont dans le cache

### Problème: La base de données ne se connecte pas
- Vérifiez les variables d'environnement
- Vérifiez que l'URL Supabase est correcte
- Vérifiez que la clé anonyme n'a pas expiré

---

## 💡 Conseils pour le Bénin

### Optimisation pour connexion lente
- Utilisez le "Mode économie" dans l'app
- Préférez le contenu audio au vidéo
- Téléchargez le contenu au cybercafé

### Distribution
- Partagez le lien via WhatsApp
- Créez des QR codes pour les écoles
- Formez les enseignants à l'utilisation

### Maintenance
- Mettez à jour le contenu régulièrement
- Ajoutez les nouveaux sujets d'examen
- Corrigez les erreurs signalées par les utilisateurs

---

**Questions? Contactez-nous: contact@fondationbenin.org**
