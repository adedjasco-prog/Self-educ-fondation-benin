export interface Concept {
  id: string;
  slug: string;
  concept_code: string;
  title_fr: string;
  title_en: string;
  title_local?: string;
  learning_objective_fr: string;
  learning_objective_en: string;
  competence_fr: string;
  niveau_maitrise: string;
  difficulty_level: number;
  estimated_minutes: number;
  tags: string[];
  prerequisite_concepts?: string[];
  leads_to_concepts?: string[];
}

export interface ContentSource {
  id: string;
  concept_id: string;
  source_type: 'video' | 'audio' | 'interactive' | 'text' | 'game' | 'pdf';
  source_platform: string;
  source_url: string;
  title_fr: string;
  title_en: string;
  description_fr?: string;
  language: string;
  explanation_style: string;
  difficulty_label: string;
  duration_seconds?: number;
  offline_available: boolean;
  rating_average?: number;
  rating_count?: number;
}

export interface Exercise {
  id: string;
  concept_id: string;
  title_fr: string;
  title_en: string;
  instructions_fr: string;
  instructions_en: string;
  difficulty: 'débutant' | 'intermédiaire' | 'avancé' | 'examen';
  exercise_type: string;
  question_text_fr: string;
  question_text_en: string;
  question_media?: any;
  options?: any[];
  correct_answer: string;
  hints?: any[];
  points: number;
  time_limit_seconds?: number;
}

export interface UserProgress {
  concept_id: string;
  status: 'verrouillé' | 'disponible' | 'en_cours' | 'pratiqué' | 'maîtrisé';
  mastery_score: number;
  exercises_completed: number;
  exercises_correct: number;
  total_time_seconds: number;
  streak_days: number;
}

export interface DiagnosticResult {
  scores_by_level: Record<string, number>;
  gap_concepts: string[];
  mastered_concepts: string[];
  recommended_start_level: number;
  recommended_start_concepts: string[];
}

export interface UserNote {
  id: string;
  concept_id: string;
  title: string;
  content_blocks: any[];
  is_public: boolean;
  created_at: string;
  updated_at: string;
}
