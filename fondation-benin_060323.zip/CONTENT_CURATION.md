# 📚 Guide de Curation de Contenu

## Comment ajouter du contenu gratuit à Fondation Bénin

---

## 🎯 Types de contenu acceptés

| Type | Description | Exemples |
|------|-------------|----------|
| **Vidéo** | YouTube, Vimeo, Khan Academy | Tutoriels, comptines, démonstrations |
| **Audio** | MP3, podcasts | Comptines, histoires, leçons orales |
| **Interactif** | Jeux, simulations | PhET, jeux éducatifs, quiz |
| **Texte** | Articles, PDF | Explications écrites, manuels |
| **Image** | Diagrammes, infographies | Schémas, tableaux, illustrations |

---

## ✅ Critères de sélection

### Qualité pédagogique
- [ ] L'explication est claire et structurée
- [ ] Adapté au niveau indiqué
- [ ] Vocabulaire approprié
- [ ] Exemples concrets et locaux

### Accessibilité
- [ ] Gratuit et légal
- [ ] Fonctionne sur mobile
- [ ] Peut fonctionner hors ligne (si possible)
- [ ] Pas de publicité intrusive

### Localisation
- [ ] En français (obligatoire)
- [ ] En langue locale si possible (Fon, Yoruba, etc.)
- [ ] Exemples culturellement pertinents pour le Bénin
- [ ] Références locales (marchés, villes, traditions)

---

## 📝 Processus d'ajout

### Étape 1: Identifier le concept
1. Trouvez le concept dans la base de données
2. Vérifiez s'il manque des types de contenu
3. Notez le niveau de difficulté actuel

### Étape 2: Trouver le contenu
Sources recommandées:
- **YouTube**: Rechercher "comptine français enfants", "mathématiques niveau CP"
- **Khan Academy**: Cours complets, bien structurés
- **African Storybook**: Histoires en langues africaines
- **PhET**: Simulations scientifiques interactives
- **Wikipedia**: Articles de base (vérifier l'exactitude)
- **Fondation Zinsou**: Contenu béninois

### Étape 3: Vérifier la qualité
1. Regardez/lisez tout le contenu
2. Vérifiez l'exactitude des informations
3. Testez sur mobile
4. Vérifiez les droits d'utilisation

### Étape 4: Ajouter à Supabase
```sql
INSERT INTO content_sources (
  concept_id,
  source_type,
  source_platform,
  source_url,
  title_fr,
  title_en,
  description_fr,
  language,
  explanation_style,
  difficulty_label,
  duration_seconds,
  offline_available
) VALUES (
  'uuid-du-concept',
  'video',
  'youtube',
  'https://www.youtube.com/embed/VIDEO_ID',
  'Titre en français',
  'Title in English',
  'Description courte',
  'fr',
  'visuel',
  'débutant',
  180,
  false
);
```

---

## 🌍 Sources par matière et niveau

### Mathématiques - Préscolaire
- **Khan Academy Kids**: Comptage, formes, couleurs
- **YouTube**: "Comptine pour enfants", "Apprendre les nombres"
- **Jeux**: PBS Kids, Starfall

### Mathématiques - Primaire
- **Khan Academy**: Arithmétique, fractions, géométrie
- **YouTube**: "Cours de maths CM1", "Exercices mathématiques"
- **Interactif**: IXL (limité), Math Playground

### Mathématiques - Collège/Lycée
- **Khan Academy**: Algèbre, géométrie, trigonométrie
- **YouTube**: "Cours de maths 3ème", "Préparation BAC"
- **WASSCE**: Archives d'examens passés

### Langue Française
- **RFI**: "Apprendre le français"
- **1jour1actu**: Actualités pour enfants
- **African Storybook**: Histoires en français

### Sciences
- **PhET**: Simulations physiques, chimie, biologie
- **Khan Academy**: Sciences naturelles
- **National Geographic Kids**: Découverte du monde

### Histoire-Géographie
- **Wikipedia**: Articles de base (vérifier)
- **UNESCO**: Ressources sur le patrimoine africain
- **YouTube**: "Histoire du Bénin", "Géographie de l'Afrique"

---

## 🎨 Créer du contenu original

### Enregistrer des vidéos
1. Utilisez un smartphone avec bon éclairage
2. Parlez clairement et lentement
3. Utilisez des objets du quotidien (mangues, noix de palme)
4. Montrez des lieux locaux (marché, école, rivière)
5. Uploadez sur YouTube (non listé)

### Enregistrer de l'audio
1. Utilisez l'app Voice Recorder du téléphone
2. Enregistrez dans un endroit calme
3. Parlez près du micro
4. Uploadez sur SoundCloud ou hébergez sur Supabase Storage

### Créer des exercices
1. Basez-vous sur le curriculum officiel
2. Utilisez des exemples locaux
3. Variez les types de questions
4. Incluez des indices progressifs
5. Testez avec des enfants réels

---

## 🔍 Vérification de qualité

### Checklist avant publication
- [ ] Le contenu est-il approprié pour l'âge?
- [ ] Les informations sont-elles exactes?
- [ ] Le contenu est-il gratuit et légal?
- [ ] Fonctionne-t-il sur mobile?
- [ ] Le chargement est-il rapide?
- [ ] Y a-t-il des publicités inappropriées?
- [ ] Le contenu est-il inclusif et respectueux?
- [ ] Les exemples sont-ils pertinents pour le Bénin?

---

## 📊 Suivi et amélioration

### Métriques à suivre
- Nombre de vues par source
- Taux de complétion
- Notes des utilisateurs
- Temps passé sur chaque type de contenu

### Amélioration continue
- Mettez à jour les liens morts
- Remplacez le contenu de faible qualité
- Ajoutez des versions en langues locales
- Créez du contenu basé sur les demandes des utilisateurs

---

**Merci de contribuer à l'éducation au Bénin! 🇧🇯**
