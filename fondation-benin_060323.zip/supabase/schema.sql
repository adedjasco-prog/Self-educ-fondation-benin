-- ============================================
-- FONDATION BENIN - SUPABASE SCHEMA
-- ============================================

-- Enable Row Level Security
alter table if exists concepts force row level security;
alter table if exists content_sources force row level security;
alter table if exists exercises force row level security;
alter table if exists user_progress force row level security;

-- ============================================
-- EDUCATION LEVELS
-- ============================================
create table if not exists education_levels (
  id int primary key,
  code text unique not null,
  name_fr text not null,
  name_en text not null,
  name_local text,
  age_range text not null,
  duration_years decimal,
  exam_at_end text,
  order_index int not null
);

-- ============================================
-- SUBJECTS
-- ============================================
create table if not exists subjects (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name_fr text not null,
  name_en text not null,
  icon text,
  color text,
  description_fr text,
  description_en text
);

-- ============================================
-- TOPICS
-- ============================================
create table if not exists topics (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid references subjects(id) on delete cascade,
  level_id int references education_levels(id),
  name_fr text not null,
  name_en text not null,
  order_index int not null,
  term int check (term in (1, 2, 3)),
  estimated_hours decimal,
  benin_programme_code text,
  competence_statement text
);

-- ============================================
-- CONCEPTS (Notion-Style Pages)
-- ============================================
create table if not exists concepts (
  id uuid primary key default gen_random_uuid(),
  topic_id uuid references topics(id) on delete cascade,
  slug text unique not null,
  concept_code text unique not null,

  -- Multilingual titles
  title_fr text not null,
  title_en text not null,
  title_local text,

  -- Learning objectives
  learning_objective_fr text not null,
  learning_objective_en text not null,
  learning_objective_local text,

  -- Benin curriculum alignment
  competence_fr text,
  niveau_maitrise text,
  criteres_evaluation jsonb default '[]'::jsonb,

  -- Difficulty & graph
  difficulty_level int check (difficulty_level between 1 and 10),
  prerequisite_concepts uuid[] default '{}',
  leads_to_concepts uuid[] default '{}',

  -- Metadata
  estimated_minutes int default 10,
  tags text[] default '{}',
  search_vector tsvector,

  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Full-text search index
create index if not exists idx_concepts_search on concepts using gin(search_vector);

-- Trigger to update search vector
create or replace function update_concept_search_vector()
returns trigger as $$
begin
  new.search_vector := 
    setweight(to_tsvector('french', coalesce(new.title_fr, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(new.title_en, '')), 'A') ||
    setweight(to_tsvector('french', coalesce(new.learning_objective_fr, '')), 'B') ||
    setweight(to_tsvector('french', coalesce(new.competence_fr, '')), 'C');
  return new;
end;
$$ language plpgsql;

create trigger trigger_update_concept_search
  before insert or update on concepts
  for each row
  execute function update_concept_search_vector();

-- ============================================
-- CONTENT SOURCES
-- ============================================
create table if not exists content_sources (
  id uuid primary key default gen_random_uuid(),
  concept_id uuid references concepts(id) on delete cascade,

  -- Source identification
  source_type text not null check (source_type in ('video', 'audio', 'interactive', 'text', 'game', 'pdf')),
  source_platform text not null,
  source_url text not null,
  embed_code text,

  -- Content metadata
  title_fr text not null,
  title_en text not null,
  title_local text,
  description_fr text,
  description_en text,
  thumbnail_url text,
  duration_seconds int,

  -- Language & localization
  language text default 'fr',
  has_subtitles boolean default false,
  subtitle_languages text[] default '{}',

  -- Pedagogy
  explanation_style text default 'visuel',
  age_appropriateness int check (age_appropriateness between 1 and 10),
  difficulty_label text default 'débutant',

  -- Quality
  curator_id uuid references auth.users(id),
  verified boolean default false,
  featured boolean default false,
  rating_average decimal(3,2) default 0,
  rating_count int default 0,

  -- Offline
  offline_available boolean default false,
  download_url text,
  file_size_bytes int,

  created_at timestamp with time zone default now()
);

-- ============================================
-- EXERCISES
-- ============================================
create table if not exists exercises (
  id uuid primary key default gen_random_uuid(),
  concept_id uuid references concepts(id) on delete cascade,

  title_fr text not null,
  title_en text not null,
  instructions_fr text not null,
  instructions_en text not null,
  instructions_local text,

  difficulty text not null check (difficulty in ('débutant', 'intermédiaire', 'avancé', 'examen')),
  exercise_type text not null,

  -- Content
  question_text_fr text not null,
  question_text_en text not null,
  question_media jsonb default '{}'::jsonb,
  options jsonb default '[]'::jsonb,
  correct_answer text not null,
  acceptable_answers text[] default '{}',

  -- Hints & solutions
  hints jsonb default '[]'::jsonb,
  solution_steps jsonb default '[]'::jsonb,
  solution_video_url text,
  common_mistakes jsonb default '[]'::jsonb,

  -- Exam alignment
  exam_source text,
  exam_year int,

  -- Gamification
  points int default 10,
  time_limit_seconds int,
  attempts_allowed int default 3,
  stars int default 3,

  created_at timestamp with time zone default now()
);

-- ============================================
-- USERS (extends auth.users)
-- ============================================
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  phone text,
  name text,

  -- Profile
  date_of_birth date,
  age_group text check (age_group in ('enfant', 'adolescent', 'adulte')),
  user_type text check (user_type in ('apprenant', 'parent', 'enseignant', 'autodidacte')),

  -- Location
  country text default 'Bénin',
  department text,
  commune text,
  language_preference text default 'fr',

  -- Goals
  primary_goal text,
  target_exam text,
  target_year int,

  -- Learning preferences
  learning_style text,
  preferred_content_type text,
  daily_goal_minutes int default 20,

  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Trigger to create profile on signup
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, email, name)
  values (new.id, new.email, new.raw_user_meta_data->>'name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function handle_new_user();

-- ============================================
-- USER PROGRESS
-- ============================================
create table if not exists user_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  concept_id uuid references concepts(id) on delete cascade,

  status text default 'verrouillé' check (status in ('verrouillé', 'disponible', 'en_cours', 'pratiqué', 'maîtrisé')),
  mastery_score decimal(5,2) default 0 check (mastery_score between 0 and 100),
  confidence_level int check (confidence_level between 1 and 5),

  content_sources_viewed uuid[] default '{}',
  preferred_source uuid,

  exercises_completed int default 0,
  exercises_correct int default 0,
  total_attempts int default 0,
  average_score decimal(5,2) default 0,

  total_time_seconds int default 0,
  streak_days int default 0,
  longest_streak int default 0,

  first_accessed timestamp with time zone,
  last_accessed timestamp with time zone,
  mastered_at timestamp with time zone,

  unique(user_id, concept_id)
);

-- ============================================
-- DIAGNOSTIC RESULTS
-- ============================================
create table if not exists diagnostic_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,

  scores_by_level jsonb default '{}'::jsonb,
  gap_concepts uuid[] default '{}',
  mastered_concepts uuid[] default '{}',

  recommended_start_level int,
  recommended_start_concepts uuid[] default '{}',
  estimated_hours_to_target int,

  completed_at timestamp with time zone default now(),
  retake_available_at timestamp with time zone
);

-- ============================================
-- USER NOTES (Notion-Style)
-- ============================================
create table if not exists user_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  concept_id uuid references concepts(id) on delete cascade,

  title text,
  content_blocks jsonb default '[]'::jsonb,

  drawings jsonb default '[]'::jsonb,
  audio_recordings text[] default '{}',
  photos text[] default '{}',

  is_public boolean default false,
  share_url text,
  shared_with uuid[] default '{}',

  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- ============================================
-- STUDY GROUPS
-- ============================================
create table if not exists study_groups (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  level_id int references education_levels(id),
  subject_id uuid references subjects(id),

  creator_id uuid references profiles(id),
  members uuid[] default '{}',
  invite_code text unique,

  shared_notes uuid[] default '{}',
  discussion_threads jsonb default '[]'::jsonb,

  created_at timestamp with time zone default now()
);

-- ============================================
-- ROW LEVEL SECURITY POLICIES
-- ============================================

-- Concepts: readable by all, writable by curators
alter table concepts enable row level security;
create policy "Concepts readable by all" on concepts for select using (true);
create policy "Concepts writable by curators" on concepts for all using (
  auth.uid() in (select id from profiles where user_type = 'enseignant')
);

-- Content Sources: readable by all
alter table content_sources enable row level security;
create policy "Sources readable by all" on content_sources for select using (true);

-- Exercises: readable by all
alter table exercises enable row level security;
create policy "Exercises readable by all" on exercises for select using (true);

-- User Progress: users can only see their own
alter table user_progress enable row level security;
create policy "Users see own progress" on user_progress for all using (auth.uid() = user_id);

-- User Notes: users can only see their own (or public ones)
alter table user_notes enable row level security;
create policy "Users see own notes" on user_notes for all using (auth.uid() = user_id);
create policy "Users see public notes" on user_notes for select using (is_public = true);

-- Profiles: users can only see/edit their own
alter table profiles enable row level security;
create policy "Users see own profile" on profiles for all using (auth.uid() = id);

-- ============================================
-- SEED DATA
-- ============================================

-- Education Levels
insert into education_levels (id, code, name_fr, name_en, age_range, duration_years, order_index) values
(0, 'maternelle_petits', 'Section des Petits', 'Small Section', '2.5-3.5 ans', 1, 0),
(1, 'maternelle_grands', 'Section des Grands', 'Large Section', '3.5-5.5 ans', 2, 1),
(2, 'ci', 'Cours Initiale (CI)', 'Initial Course', '5-6 ans', 1, 2),
(3, 'cp', 'Cours Préparatoire (CP)', 'Preparatory Course', '6-7 ans', 1, 3),
(4, 'ce1', 'Cours Élémentaire 1 (CE1)', 'Elementary 1', '7-8 ans', 1, 4),
(5, 'ce2', 'Cours Élémentaire 2 (CE2)', 'Elementary 2', '8-9 ans', 1, 5),
(6, 'cm1', 'Cours Moyen 1 (CM1)', 'Middle 1', '9-10 ans', 1, 6),
(7, 'cm2', 'Cours Moyen 2 (CM2)', 'Middle 2', '10-11 ans', 1, 7),
(8, 'sixieme', 'Sixième (6ème)', '6th Grade', '11-12 ans', 1, 8),
(9, 'cinquieme', 'Cinquième (5ème)', '5th Grade', '12-13 ans', 1, 9),
(10, 'quatrieme', 'Quatrième (4ème)', '4th Grade', '13-14 ans', 1, 10),
(11, 'troisieme', 'Troisième (3ème)', '3rd Grade', '14-15 ans', 1, 11),
(12, 'seconde', 'Seconde (2nde)', '10th Grade', '15-16 ans', 1, 12),
(13, 'premiere', 'Première (1ère)', '11th Grade', '16-17 ans', 1, 13),
(14, 'terminale', 'Terminale (Tle)', '12th Grade', '17-18 ans', 1, 14)
on conflict (id) do nothing;

-- Subjects
insert into subjects (id, code, name_fr, name_en, icon, color) values
('lang', 'LANG', 'Langage et Communication', 'Language and Communication', 'BookOpen', '#E74C3C'),
('math', 'MATH', 'Mathématiques', 'Mathematics', 'Calculator', '#3498DB'),
('sci', 'SCI', 'Découverte du Monde', 'World Discovery', 'Globe', '#2ECC71'),
('art', 'ART', 'Arts Plastiques', 'Visual Arts', 'Palette', '#9B59B6'),
('tech', 'TECH', 'Technologie Simple', 'Simple Technology', 'Wrench', '#F39C12'),
('soc', 'SOC', 'Vivre Ensemble', 'Living Together', 'Users', '#1ABC9C')
on conflict (id) do nothing;

-- ============================================
-- FUNCTIONS
-- ============================================

-- Get user's learning path
create or replace function get_learning_path(p_user_id uuid)
returns table (
  concept_id uuid,
  concept_title text,
  concept_slug text,
  status text,
  mastery_score decimal,
  next_unlocked boolean
) as $$
begin
  return query
  select 
    c.id as concept_id,
    c.title_fr as concept_title,
    c.slug as concept_slug,
    coalesce(up.status, 'verrouillé') as status,
    coalesce(up.mastery_score, 0) as mastery_score,
    case 
      when up.status = 'maîtrisé' then true
      when up.status is null and (
        c.prerequisite_concepts = '{}' or
        c.prerequisite_concepts <@ (
          select array_agg(concept_id) 
          from user_progress 
          where user_id = p_user_id and status = 'maîtrisé'
        )
      ) then true
      else false
    end as next_unlocked
  from concepts c
  left join user_progress up on up.concept_id = c.id and up.user_id = p_user_id
  order by c.difficulty_level, c.order_index;
end;
$$ language plpgsql;

-- Update user streak
create or replace function update_streak(p_user_id uuid, p_concept_id uuid)
returns void as $$
declare
  last_accessed timestamp with time zone;
  current_streak int;
begin
  select up.last_accessed, up.streak_days 
  into last_accessed, current_streak
  from user_progress up
  where up.user_id = p_user_id and up.concept_id = p_concept_id;

  if last_accessed is null or last_accessed < current_date - interval '1 day' then
    update user_progress 
    set streak_days = 1, last_accessed = now()
    where user_id = p_user_id and concept_id = p_concept_id;
  elsif last_accessed >= current_date then
    -- Already accessed today, do nothing
    null;
  else
    update user_progress 
    set streak_days = streak_days + 1, 
        longest_streak = greatest(longest_streak, streak_days + 1),
        last_accessed = now()
    where user_id = p_user_id and concept_id = p_concept_id;
  end if;
end;
$$ language plpgsql;
