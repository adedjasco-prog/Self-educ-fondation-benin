/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'benin-green': '#00843D',
        'benin-yellow': '#FCD116',
        'benin-red': '#E8112D',
        'warm-cream': '#FFF8E7',
        'soft-orange': '#FF9F43',
        'sky-blue': '#74B9FF',
        'lavender': '#A29BFE',
      },
      fontFamily: {
        'rounded': ['Nunito', 'sans-serif'],
      },
    },
  },
  plugins: [],
}