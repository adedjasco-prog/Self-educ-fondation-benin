import { createClient } from '@supabase/supabase-js'
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''

// Client for server components and API routes
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Client for client components (handles auth automatically)
export const supabaseClient = () => createClientComponentClient()

// Database types (for TypeScript)
export type Database = {
  public: {
    Tables: {
      concepts: {
        Row: {
          id: string
          slug: string
          concept_code: string
          title_fr: string
          title_en: string
          title_local: string | null
          learning_objective_fr: string
          learning_objective_en: string
          competence_fr: string
          difficulty_level: number
          estimated_minutes: number
        }
      }
      content_sources: {
        Row: {
          id: string
          concept_id: string
          source_type: string
          source_platform: string
          source_url: string
          title_fr: string
          title_en: string
          language: string
          explanation_style: string
          difficulty_label: string
          duration_seconds: number | null
          offline_available: boolean
          rating_average: number | null
          rating_count: number
        }
      }
      exercises: {
        Row: {
          id: string
          concept_id: string
          title_fr: string
          title_en: string
          difficulty: string
          exercise_type: string
          question_text_fr: string
          question_text_en: string
          options: any
          correct_answer: string
          hints: any
          points: number
          time_limit_seconds: number | null
        }
      }
      user_progress: {
        Row: {
          id: string
          user_id: string
          concept_id: string
          status: string
          mastery_score: number
          exercises_completed: number
          exercises_correct: number
          total_time_seconds: number
          streak_days: number
        }
      }
    }
  }
}
