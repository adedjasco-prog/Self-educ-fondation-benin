// Offline storage using IndexedDB for PWA

const DB_NAME = 'fondation-benin'
const DB_VERSION = 1

interface OfflineContent {
  conceptId: string
  content: any
  downloadedAt: string
}

interface PendingProgress {
  id: string
  userId: string
  conceptId: string
  status: string
  score: number
  timestamp: string
}

export async function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result

      if (!db.objectStoreNames.contains('offlineContent')) {
        db.createObjectStore('offlineContent', { keyPath: 'conceptId' })
      }

      if (!db.objectStoreNames.contains('pendingProgress')) {
        db.createObjectStore('pendingProgress', { keyPath: 'id' })
      }

      if (!db.objectStoreNames.contains('userNotes')) {
        db.createObjectStore('userNotes', { keyPath: 'id', autoIncrement: true })
      }

      if (!db.objectStoreNames.contains('cachedConcepts')) {
        db.createObjectStore('cachedConcepts', { keyPath: 'slug' })
      }
    }
  })
}

// Store content for offline use
export async function storeOfflineContent(conceptId: string, content: any): Promise<void> {
  const db = await openDB()
  const tx = db.transaction('offlineContent', 'readwrite')
  const store = tx.objectStore('offlineContent')

  await store.put({
    conceptId,
    content,
    downloadedAt: new Date().toISOString()
  })
}

// Get offline content
export async function getOfflineContent(conceptId: string): Promise<any | null> {
  const db = await openDB()
  const tx = db.transaction('offlineContent', 'readonly')
  const store = tx.objectStore('offlineContent')

  const request = store.get(conceptId)

  return new Promise((resolve, reject) => {
    request.onsuccess = () => {
      const result = request.result
      resolve(result ? result.content : null)
    }
    request.onerror = () => reject(request.error)
  })
}

// Queue progress update for sync
export async function queueProgressUpdate(
  userId: string,
  conceptId: string,
  status: string,
  score: number
): Promise<void> {
  const db = await openDB()
  const tx = db.transaction('pendingProgress', 'readwrite')
  const store = tx.objectStore('pendingProgress')

  await store.put({
    id: `${userId}-${conceptId}-${Date.now()}`,
    userId,
    conceptId,
    status,
    score,
    timestamp: new Date().toISOString()
  })

  // Request background sync if available
  if ('serviceWorker' in navigator && 'SyncManager' in window) {
    const registration = await navigator.serviceWorker.ready
    await registration.sync.register('sync-progress')
  }
}

// Get all pending progress updates
export async function getPendingProgress(): Promise<PendingProgress[]> {
  const db = await openDB()
  const tx = db.transaction('pendingProgress', 'readonly')
  const store = tx.objectStore('pendingProgress')

  const request = store.getAll()

  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

// Clear pending progress after sync
export async function clearPendingProgress(id: string): Promise<void> {
  const db = await openDB()
  const tx = db.transaction('pendingProgress', 'readwrite')
  const store = tx.objectStore('pendingProgress')

  await store.delete(id)
}

// Check if online
export function isOnline(): boolean {
  return navigator.onLine
}

// Listen for online/offline events
export function setupConnectivityListeners(
  onOnline: () => void,
  onOffline: () => void
): () => void {
  window.addEventListener('online', onOnline)
  window.addEventListener('offline', onOffline)

  return () => {
    window.removeEventListener('online', onOnline)
    window.removeEventListener('offline', onOffline)
  }
}

// Cache concept data
export async function cacheConcept(slug: string, data: any): Promise<void> {
  const db = await openDB()
  const tx = db.transaction('cachedConcepts', 'readwrite')
  const store = tx.objectStore('cachedConcepts')

  await store.put({
    slug,
    data,
    cachedAt: new Date().toISOString()
  })
}

// Get cached concept
export async function getCachedConcept(slug: string): Promise<any | null> {
  const db = await openDB()
  const tx = db.transaction('cachedConcepts', 'readonly')
  const store = tx.objectStore('cachedConcepts')

  const request = store.get(slug)

  return new Promise((resolve, reject) => {
    request.onsuccess = () => {
      const result = request.result
      resolve(result ? result.data : null)
    }
    request.onerror = () => reject(request.error)
  })
}
